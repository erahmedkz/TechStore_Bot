import os
import logging
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackContext, CallbackQueryHandler, ConversationHandler, MessageHandler, filters
from database import Database
from localization import get_text
from models import User, Product, Cart, Order

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# States for conversation handler
LANGUAGE, REGISTRATION_NAME, REGISTRATION_PHONE, MAIN_MENU, CATALOG, PRODUCT_DETAIL, CART, CHECKOUT = range(8)

# Admin states
ADMIN_MENU, ADMIN_PRODUCTS, ADMIN_CATEGORIES, ADMIN_ORDERS, ADMIN_ADD_PRODUCT, ADMIN_EDIT_PRODUCT, \
ADMIN_ADD_CATEGORY, ADMIN_EDIT_CATEGORY, ADMIN_ORDER_DETAILS, ADMIN_PRODUCT_SEARCH = range(10, 20)

# Initialize database
db = Database()

# Language options
LANGUAGES = {
    'ru': 'Русский',
    'kk': 'Қазақша'
}

async def start(update: Update, context: CallbackContext) -> int:
    """Start the conversation and ask for language."""
    user_id = update.effective_user.id
    user = db.get_user(user_id)
    
    if user and user.language:
        context.user_data['language'] = user.language
        return await show_main_menu(update, context)
    
    keyboard = [
        [InlineKeyboardButton(LANGUAGES['ru'], callback_data='language_ru')],
        [InlineKeyboardButton(LANGUAGES['kk'], callback_data='language_kk')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        'Выберите язык / Тілді таңдаңыз:',
        reply_markup=reply_markup
    )
    return LANGUAGE

async def language_selection(update: Update, context: CallbackContext) -> int:
    """Process language selection and ask for registration if needed."""
    query = update.callback_query
    await query.answer()
    
    language = query.data.split('_')[1]
    context.user_data['language'] = language
    
    user_id = update.effective_user.id
    user = db.get_user(user_id)
    
    if user:
        db.update_user_language(user_id, language)
        return await show_main_menu(update, context)
    else:
        await query.edit_message_text(get_text('ask_name', language))
        return REGISTRATION_NAME

async def register_name(update: Update, context: CallbackContext) -> int:
    """Process user's name and ask for phone number."""
    name = update.message.text
    context.user_data['name'] = name
    
    language = context.user_data.get('language', 'ru')
    await update.message.reply_text(get_text('ask_phone', language))
    return REGISTRATION_PHONE

async def register_phone(update: Update, context: CallbackContext) -> int:
    """Process user's phone number and complete registration."""
    phone = update.message.text
    name = context.user_data.get('name')
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    
    db.create_user(user_id, name, phone, language)
    
    await update.message.reply_text(get_text('registration_complete', language))
    return await show_main_menu(update, context)

async def show_main_menu(update: Update, context: CallbackContext) -> int:
    """Show the main menu."""
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    is_admin = db.is_admin(user_id)
    
    keyboard = [
        [InlineKeyboardButton(get_text('catalog', language), callback_data='catalog')],
        [InlineKeyboardButton(get_text('search', language), callback_data='search')],
        [InlineKeyboardButton(get_text('cart', language), callback_data='cart')],
        [InlineKeyboardButton(get_text('orders', language), callback_data='orders')],
        [InlineKeyboardButton(get_text('wishlist', language), callback_data='wishlist')],
        [InlineKeyboardButton(get_text('faq', language), callback_data='faq')],
        [InlineKeyboardButton(get_text('settings', language), callback_data='settings')]
    ]
    
    # Add admin panel button if user is admin
    if is_admin:
        keyboard.append([InlineKeyboardButton(get_text('admin_panel', language), callback_data='admin_panel')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            get_text('main_menu', language),
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            get_text('main_menu', language),
            reply_markup=reply_markup
        )
    
    return MAIN_MENU

async def show_catalog(update: Update, context: CallbackContext) -> int:
    """Show product categories."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    categories = db.get_categories()
    
    keyboard = []
    for category in categories:
        keyboard.append([InlineKeyboardButton(category.name, callback_data=f'category_{category.id}')])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('choose_category', language),
        reply_markup=reply_markup
    )
    return CATALOG

async def show_category_products(update: Update, context: CallbackContext) -> int:
    """Show products in a category."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    category_id = int(query.data.split('_')[1])
    products = db.get_products_by_category(category_id)
    
    keyboard = []
    for product in products:
        keyboard.append([InlineKeyboardButton(product.name, callback_data=f'product_{product.id}')])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_catalog')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('choose_product', language),
        reply_markup=reply_markup
    )
    return CATALOG

async def show_product_detail(update: Update, context: CallbackContext) -> int:
    """Show product details."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    product_id = int(query.data.split('_')[1])
    product = db.get_product(product_id)
    user_id = update.effective_user.id
    
    # Check if product is in wishlist
    is_in_wishlist = False
    if hasattr(db, 'is_in_wishlist'):
        is_in_wishlist = db.is_in_wishlist(user_id, product_id)
    
    # Get product reviews
    reviews = []
    if hasattr(db, 'get_product_reviews'):
        reviews = db.get_product_reviews(product_id)
    
    # Calculate average rating
    avg_rating = 0
    if reviews:
        avg_rating = sum(review.rating for review in reviews) / len(reviews)
    
    # Build keyboard
    keyboard = [
        [InlineKeyboardButton(get_text('add_to_cart', language), callback_data=f'add_to_cart_{product_id}')]
    ]
    
    # Add wishlist button
    if is_in_wishlist:
        keyboard.append([InlineKeyboardButton(
            get_text('remove_from_wishlist', language), 
            callback_data=f'remove_wishlist_{product_id}'
        )])
    else:
        keyboard.append([InlineKeyboardButton(
            get_text('add_to_wishlist', language), 
            callback_data=f'add_wishlist_{product_id}'
        )])
    
    # Add reviews button if there are reviews
    if reviews:
        keyboard.append([InlineKeyboardButton(
            f"{get_text('product_reviews', language)} ({len(reviews)})", 
            callback_data=f'reviews_{product_id}'
        )])
    
    # Add write review button
    keyboard.append([InlineKeyboardButton(
        get_text('write_review', language), 
        callback_data=f'write_review_{product_id}'
    )])
    
    # Add back button
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_category')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Build product info
    product_info = f"{product.name}\n\n{product.description}\n\n"
    
    # Add rating if available
    if avg_rating > 0:
        stars = '★' * int(avg_rating) + '☆' * (5 - int(avg_rating))
        product_info += f"{get_text('product_rating', language)}: {stars} ({avg_rating:.1f})\n\n"
    
    # Add price and stock info
    product_info += f"{get_text('price', language)}: {product.price} ₸\n"
    product_info += f"{get_text('in_stock' if product.in_stock else 'out_of_stock', language)}"
    
    await query.edit_message_text(
        product_info,
        reply_markup=reply_markup
    )
    return PRODUCT_DETAIL

async def add_to_wishlist(update: Update, context: CallbackContext) -> int:
    """Add product to wishlist."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    product_id = int(query.data.split('_')[1])
    
    # Add to wishlist in database
    if hasattr(db, 'add_to_wishlist'):
        db.add_to_wishlist(user_id, product_id)
    
    # Show confirmation message
    await query.answer(get_text('added_to_wishlist', language), show_alert=True)
    
    # Return to product detail
    return await show_product_detail(update, context)

async def remove_from_wishlist(update: Update, context: CallbackContext) -> int:
    """Remove product from wishlist."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    product_id = int(query.data.split('_')[1])
    
    # Remove from wishlist in database
    if hasattr(db, 'remove_from_wishlist'):
        db.remove_from_wishlist(user_id, product_id)
    
    # Show confirmation message
    await query.answer(get_text('removed_from_wishlist', language), show_alert=True)
    
    # Return to product detail
    return await show_product_detail(update, context)

async def add_to_cart(update: Update, context: CallbackContext) -> int:
    """Add product to cart."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    product_id = int(query.data.split('_')[3])
    
    # Add product to cart in database
    db.add_to_cart(user_id, product_id, 1)
    
    await query.edit_message_text(
        get_text('added_to_cart', language),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text('continue_shopping', language), callback_data='back_to_category')],
            [InlineKeyboardButton(get_text('go_to_cart', language), callback_data='cart')]
        ])
    )
    return PRODUCT_DETAIL

async def show_cart(update: Update, context: CallbackContext) -> int:
    """Show user's cart."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    cart_items = db.get_cart_items(user_id)
    
    if not cart_items:
        await query.edit_message_text(
            get_text('empty_cart', language),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
            ])
        )
        return CART
    
    # Calculate total price
    total = sum(item.product.price * item.quantity for item in cart_items)
    
    # Prepare cart message
    cart_text = get_text('your_cart', language) + "\n\n"
    for item in cart_items:
        cart_text += f"{item.product.name} x {item.quantity} = {item.product.price * item.quantity} ₸\n"
    
    cart_text += f"\n{get_text('total', language)}: {total} ₸"
    
    keyboard = [
        [InlineKeyboardButton(get_text('checkout', language), callback_data='checkout')],
        [InlineKeyboardButton(get_text('clear_cart', language), callback_data='clear_cart')],
        [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(cart_text, reply_markup=reply_markup)
    return CART

async def clear_cart(update: Update, context: CallbackContext) -> int:
    """Clear user's cart."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    
    # Clear cart in database
    db.clear_cart(user_id)
    
    await query.edit_message_text(
        get_text('cart_cleared', language),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
        ])
    )
    return CART

async def checkout(update: Update, context: CallbackContext) -> int:
    """Process checkout."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    
    # Create order from cart
    order_id = db.create_order_from_cart(user_id)
    
    if order_id:
        await query.edit_message_text(
            get_text('order_created', language).format(order_id=order_id),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
            ])
        )
    else:
        await query.edit_message_text(
            get_text('checkout_error', language),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='cart')]
            ])
        )
    
    return CHECKOUT

async def show_orders(update: Update, context: CallbackContext) -> int:
    """Show user's orders."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    orders = db.get_user_orders(user_id)
    
    if not orders:
        await query.edit_message_text(
            get_text('no_orders', language),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
            ])
        )
        return MAIN_MENU
    
    # Prepare orders message
    orders_text = get_text('your_orders', language) + "\n\n"
    for order in orders:
        status_text = get_text(f'order_status_{order.status}', language)
        orders_text += f"#{order.id} - {order.created_at} - {status_text} - {order.total} ₸\n"
    
    keyboard = [
        [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(orders_text, reply_markup=reply_markup)
    return MAIN_MENU

async def show_settings(update: Update, context: CallbackContext) -> int:
    """Show settings menu."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    
    keyboard = [
        [InlineKeyboardButton(get_text('change_language', language), callback_data='change_language')],
        [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('settings', language),
        reply_markup=reply_markup
    )
    return MAIN_MENU

async def change_language(update: Update, context: CallbackContext) -> int:
    """Show language selection menu."""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton(LANGUAGES['ru'], callback_data='language_ru')],
        [InlineKeyboardButton(LANGUAGES['kk'], callback_data='language_kk')],
        [InlineKeyboardButton(get_text('back', context.user_data.get('language', 'ru')), callback_data='back_to_settings')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        'Выберите язык / Тілді таңдаңыз:',
        reply_markup=reply_markup
    )
    return MAIN_MENU

async def back_to_settings(update: Update, context: CallbackContext) -> int:
    """Return to settings menu."""
    query = update.callback_query
    await query.answer()
    return await show_settings(update, context)

async def back_to_main(update: Update, context: CallbackContext) -> int:
    """Return to main menu."""
    query = update.callback_query
    await query.answer()
    return await show_main_menu(update, context)

async def back_to_catalog(update: Update, context: CallbackContext) -> int:
    """Return to catalog."""
    query = update.callback_query
    await query.answer()
    return await show_catalog(update, context)

async def back_to_category(update: Update, context: CallbackContext) -> int:
    """Return to category products."""
    query = update.callback_query
    await query.answer()
    # We need to get the category_id from context
    return await show_catalog(update, context)

# Admin panel handlers
async def show_admin_panel(update: Update, context: CallbackContext) -> int:
    """Show admin panel menu."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    
    keyboard = [
        [InlineKeyboardButton(get_text('manage_products', language), callback_data='admin_products')],
        [InlineKeyboardButton(get_text('manage_categories', language), callback_data='admin_categories')],
        [InlineKeyboardButton(get_text('manage_orders', language), callback_data='admin_orders')],
        [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('admin_panel', language),
        reply_markup=reply_markup
    )
    return ADMIN_MENU

async def show_admin_products(update: Update, context: CallbackContext) -> int:
    """Show product management menu."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    
    keyboard = [
        [InlineKeyboardButton(get_text('add_product', language), callback_data='add_product')],
        [InlineKeyboardButton(get_text('search_products', language), callback_data='search_products')],
        [InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('manage_products', language),
        reply_markup=reply_markup
    )
    return ADMIN_PRODUCTS

async def admin_search_products(update: Update, context: CallbackContext) -> int:
    """Show product search interface for admin."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    
    await query.edit_message_text(
        get_text('search_placeholder', language),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin_products')]
        ])
    )
    
    # Set state to wait for search query
    context.user_data['awaiting_admin_search'] = True
    return ADMIN_PRODUCT_SEARCH

async def process_admin_product_search(update: Update, context: CallbackContext) -> int:
    """Process admin product search query and show results."""
    if not context.user_data.get('awaiting_admin_search'):
        return ADMIN_PRODUCTS
    
    query_text = update.message.text
    language = context.user_data.get('language', 'ru')
    products = db.search_products(query_text, language)
    
    if not products:
        await update.message.reply_text(
            get_text('no_search_results', language),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin_products')]
            ])
        )
        return ADMIN_PRODUCT_SEARCH
    
    keyboard = []
    for product in products:
        keyboard.append([InlineKeyboardButton(
            f"🖊️ {product.name}", 
            callback_data=f'edit_product_{product.id}'
        )])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin_products')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        get_text('search_results', language),
        reply_markup=reply_markup
    )
    
    # Reset search state
    context.user_data['awaiting_admin_search'] = False
    return ADMIN_EDIT_PRODUCT

async def start_add_product(update: Update, context: CallbackContext) -> int:
    """Start the add product process."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    categories = db.get_categories()
    
    # Reset product data
    context.user_data['new_product'] = {
        'step': 'category',
        'data': {}
    }
    
    # Show category selection
    keyboard = []
    for category in categories:
        keyboard.append([InlineKeyboardButton(
            category.name, 
            callback_data=f'new_product_category_{category.id}'
        )])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin_products')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('product_category', language),
        reply_markup=reply_markup
    )
    return ADMIN_ADD_PRODUCT

async def process_add_product_category(update: Update, context: CallbackContext) -> int:
    """Process category selection for new product."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    category_id = int(query.data.split('_')[-1])
    
    # Save category id
    context.user_data['new_product']['data']['category_id'] = category_id
    context.user_data['new_product']['step'] = 'name'
    
    await query.edit_message_text(
        get_text('product_name', language),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text('back', language), callback_data='back_to_add_product')]
        ])
    )
    return ADMIN_ADD_PRODUCT

async def back_to_admin_products(update: Update, context: CallbackContext) -> int:
    """Return to admin products menu."""
    query = update.callback_query
    await query.answer()
    return await show_admin_products(update, context)

async def show_admin_categories(update: Update, context: CallbackContext) -> int:
    """Show category management menu."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    categories = db.get_categories()
    
    keyboard = [
        [InlineKeyboardButton(get_text('add_category', language), callback_data='add_category')]
    ]
    
    # Add existing categories
    for category in categories:
        keyboard.append([InlineKeyboardButton(
            f"🖊️ {category.name}", callback_data=f'edit_category_{category.id}'
        )])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('manage_categories', language),
        reply_markup=reply_markup
    )
    return ADMIN_CATEGORIES

async def show_admin_orders(update: Update, context: CallbackContext) -> int:
    """Show order management menu."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    orders = db.get_all_orders(limit=10)
    
    keyboard = []
    
    # Add order status filters
    status_row = [
        InlineKeyboardButton("🔄 " + get_text('order_status_pending', language), callback_data='filter_orders_pending'),
        InlineKeyboardButton("⏳ " + get_text('order_status_processing', language), callback_data='filter_orders_processing')
    ]
    keyboard.append(status_row)
    
    status_row2 = [
        InlineKeyboardButton("📦 " + get_text('order_status_shipped', language), callback_data='filter_orders_shipped'),
        InlineKeyboardButton("✅ " + get_text('order_status_delivered', language), callback_data='filter_orders_delivered')
    ]
    keyboard.append(status_row2)
    
    # Add recent orders
    for order in orders:
        keyboard.append([InlineKeyboardButton(
            f"#{order['id']} - {order['user_name']} - {order['total']} ₸",
            callback_data=f'order_details_{order['id']}'
        )])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_admin')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('manage_orders', language),
        reply_markup=reply_markup
    )
    return ADMIN_ORDERS

async def back_to_admin(update: Update, context: CallbackContext) -> int:
    """Return to admin panel menu."""
    query = update.callback_query
    await query.answer()
    return await show_admin_panel(update, context)

# Search functionality
async def show_search(update: Update, context: CallbackContext) -> int:
    """Show search interface."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    
    await query.edit_message_text(
        get_text('search_placeholder', language),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
        ])
    )
    
    # Set state to wait for search query
    context.user_data['awaiting_search'] = True
    return MAIN_MENU

async def process_search(update: Update, context: CallbackContext) -> int:
    """Process search query and show results."""
    if not context.user_data.get('awaiting_search'):
        return MAIN_MENU
    
    query_text = update.message.text
    language = context.user_data.get('language', 'ru')
    products = db.search_products(query_text, language)
    
    if not products:
        await update.message.reply_text(
            get_text('no_search_results', language),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
            ])
        )
        return MAIN_MENU
    
    keyboard = []
    for product in products:
        keyboard.append([InlineKeyboardButton(product.name, callback_data=f'product_{product.id}')])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        get_text('search_results', language),
        reply_markup=reply_markup
    )
    
    # Reset search state
    context.user_data['awaiting_search'] = False
    return CATALOG

# Wishlist functionality
async def show_wishlist(update: Update, context: CallbackContext) -> int:
    """Show user's wishlist."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    user_id = update.effective_user.id
    
    # This would need to be implemented in the database class
    wishlist_items = db.get_wishlist_items(user_id) if hasattr(db, 'get_wishlist_items') else []
    
    if not wishlist_items:
        await query.edit_message_text(
            get_text('empty_wishlist', language),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')]
            ])
        )
        return MAIN_MENU
    
    keyboard = []
    for item in wishlist_items:
        keyboard.append([InlineKeyboardButton(item.product.name, callback_data=f'product_{item.product.id}')])
    
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('your_wishlist', language),
        reply_markup=reply_markup
    )
    return CATALOG

# FAQ functionality
async def show_faq(update: Update, context: CallbackContext) -> int:
    """Show FAQ section."""
    query = update.callback_query
    await query.answer()
    
    language = context.user_data.get('language', 'ru')
    
    # This would need to be implemented in the database class
    faqs = db.get_faqs(language) if hasattr(db, 'get_faqs') else []
    
    keyboard = []
    for faq in faqs:
        keyboard.append([InlineKeyboardButton(faq['question'], callback_data=f'faq_{faq['id']}')])
    
    keyboard.append([InlineKeyboardButton(get_text('contact_support', language), callback_data='contact_support')])
    keyboard.append([InlineKeyboardButton(get_text('back', language), callback_data='back_to_main')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        get_text('faq_title', language),
        reply_markup=reply_markup
    )
    return MAIN_MENU

# Create conversation handler
# Add this import at the top with other imports
from datetime import datetime
import pytz

# Update the conversation handler configuration
conv_handler = ConversationHandler(
    entry_points=[CommandHandler('start', start)],
    states={
        LANGUAGE: [
            CallbackQueryHandler(language_selection, pattern='^language_')
        ],
        REGISTRATION_NAME: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, register_name)
        ],
        REGISTRATION_PHONE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, register_phone)
        ],
        MAIN_MENU: [
            CallbackQueryHandler(show_catalog, pattern='^catalog$'),
            CallbackQueryHandler(show_cart, pattern='^cart$'),
            CallbackQueryHandler(show_orders, pattern='^orders$'),
            CallbackQueryHandler(show_settings, pattern='^settings$'),
            CallbackQueryHandler(show_admin_panel, pattern='^admin_panel$'),
            CallbackQueryHandler(show_search, pattern='^search$'),
            CallbackQueryHandler(show_wishlist, pattern='^wishlist$'),
            CallbackQueryHandler(show_faq, pattern='^faq$'),
            CallbackQueryHandler(change_language, pattern='^change_language$'),
            CallbackQueryHandler(back_to_main, pattern='^back_to_main$'),
            MessageHandler(filters.TEXT & ~filters.COMMAND, process_search)
        ],
        CATALOG: [
            CallbackQueryHandler(show_category_products, pattern='^category_'),
            CallbackQueryHandler(show_product_detail, pattern='^product_'),
            CallbackQueryHandler(back_to_main, pattern='^back_to_main$'),
            CallbackQueryHandler(back_to_catalog, pattern='^back_to_catalog$')
        ],
        PRODUCT_DETAIL: [
            CallbackQueryHandler(add_to_cart, pattern='^add_to_cart_'),
            CallbackQueryHandler(back_to_category, pattern='^back_to_category$'),
            CallbackQueryHandler(show_cart, pattern='^cart$')
        ],
        CART: [
            CallbackQueryHandler(checkout, pattern='^checkout$'),
            CallbackQueryHandler(clear_cart, pattern='^clear_cart$'),
            CallbackQueryHandler(back_to_main, pattern='^back_to_main$')
        ],
        CHECKOUT: [
            CallbackQueryHandler(back_to_main, pattern='^back_to_main$')
        ],
        ADMIN_MENU: [
            CallbackQueryHandler(show_admin_products, pattern='^admin_products$'),
            CallbackQueryHandler(show_admin_categories, pattern='^admin_categories$'),
            CallbackQueryHandler(show_admin_orders, pattern='^admin_orders$'),
            CallbackQueryHandler(back_to_main, pattern='^back_to_main$')
        ],
        ADMIN_PRODUCTS: [
            CallbackQueryHandler(start_add_product, pattern='^add_product$'),
            CallbackQueryHandler(admin_search_products, pattern='^search_products$'),
            CallbackQueryHandler(back_to_admin, pattern='^back_to_admin$')
        ],
        ADMIN_PRODUCT_SEARCH: [
            CallbackQueryHandler(back_to_admin_products, pattern='^back_to_admin_products$'),
            MessageHandler(filters.TEXT & ~filters.COMMAND, process_admin_product_search)
        ],
        ADMIN_ADD_PRODUCT: [
            CallbackQueryHandler(process_add_product_category, pattern='^new_product_category_'),
            CallbackQueryHandler(back_to_admin_products, pattern='^back_to_add_product$'),
            CallbackQueryHandler(back_to_admin_products, pattern='^back_to_admin_products$')
        ],
        ADMIN_EDIT_PRODUCT: [
            CallbackQueryHandler(back_to_admin_products, pattern='^back_to_admin_products$')
        ],
        ADMIN_CATEGORIES: [
            CallbackQueryHandler(back_to_admin, pattern='^back_to_admin$')
        ],
        ADMIN_ORDERS: [
            CallbackQueryHandler(back_to_admin, pattern='^back_to_admin$')
        ]
    },
    fallbacks=[CallbackQueryHandler(start, pattern='^start$')],
    per_message=False,  # Changed to False to fix message handling
    per_chat=True,  # Enabled to maintain conversation state per chat
    name='shop_conversation'
)

async def error_handler(update: Update, context: CallbackContext) -> None:
    """Log errors and send a message to the user."""
    logger.error(f"Update {update} caused error {context.error}")
    
    if update and update.message:
        await update.message.reply_text(
            "Произошла ошибка. Пожалуйста, попробуйте снова."
        )

def main() -> None:
    """Start the bot."""
    token = os.getenv('TELEGRAM_TOKEN')
    if not token:
        logger.error("No TELEGRAM_TOKEN found in environment variables!")
        return

    try:
        application = Application.builder()\
            .token(token)\
            .concurrent_updates(True)\
            .build()

        # Add error handler
        application.add_error_handler(error_handler)

        # Add conversation handler
        application.add_handler(conv_handler)

        # Start the Bot
        application.run_polling(allowed_updates=Update.ALL_TYPES)
        logger.info("Bot started. Press Ctrl+C to stop.")
    except Exception as e:
        logger.error(f"Error starting bot: {e}")

if __name__ == '__main__':
    main()