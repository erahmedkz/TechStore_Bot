import os
import psycopg2

try:
    # Connect to the database using the same connection parameters as in the application
    conn = psycopg2.connect(
        host=os.getenv('DB_HOST', 'localhost'),
        database=os.getenv('DB_NAME', 'techshop'),
        user=os.getenv('DB_USER', 'postgres'),
        password=os.getenv('DB_PASSWORD', '12345'),
        port=os.getenv('DB_PORT', '5432')
    )
    
    cursor = conn.cursor()
    
    # Check if users table exists
    cursor.execute("SELECT EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = 'users')")
    table_exists = cursor.fetchone()[0]
    print(f"Users table exists: {table_exists}")
    
    if table_exists:
        # Get columns in users table
        cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'users'")
        columns = [col[0] for col in cursor.fetchall()]
        print(f"Columns in users table: {columns}")
        
        # Check if is_admin column exists
        is_admin_exists = 'is_admin' in columns
        print(f"is_admin column exists: {is_admin_exists}")
        
        if not is_admin_exists:
            print("\nThe is_admin column is missing. Adding it now...")
            cursor.execute("ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT FALSE")
            conn.commit()
            print("is_admin column added successfully!")
    
    conn.close()
    print("Database check completed.")
    
except Exception as e:
    print(f"Error: {e}")