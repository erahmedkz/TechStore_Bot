import os
import psycopg2
from psycopg2 import pool
from dotenv import load_dotenv
from models import User, Product, Category, Cart, CartItem, Order, OrderItem

# Load environment variables
load_dotenv()

class Database:
    """Database handler for the Telegram bot."""
    
    def __init__(self):
        """Initialize database connection pool."""
        self.connection_pool = psycopg2.pool.SimpleConnectionPool(
            minconn=1,
            maxconn=10,
            host=os.getenv('DB_HOST', 'localhost'),
            database=os.getenv('DB_NAME', 'techshop'),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', '12345'),
            port=os.getenv('DB_PORT', '5432'),
            options=f"-c timezone=UTC"
        )
        
        # Create tables if they don't exist
        self._create_tables()
    
    def _create_tables(self):
        """Create database tables if they don't exist."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Create users table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id BIGINT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    phone VARCHAR(20) NOT NULL,
                    language VARCHAR(2) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_admin BOOLEAN DEFAULT FALSE
                )
                """)
                
                # Create categories table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS categories (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    name_kk VARCHAR(100) NOT NULL,
                    parent_id INTEGER REFERENCES categories(id),
                    image_url VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """)
                
                # Add column if not exists for existing databases
                cursor.execute("""
                ALTER TABLE categories 
                ADD COLUMN IF NOT EXISTS parent_id INTEGER REFERENCES categories(id)
                """)
                
                # Create products table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id SERIAL PRIMARY KEY,
                    category_id INTEGER REFERENCES categories(id),
                    name VARCHAR(100) NOT NULL,
                    name_kk VARCHAR(100) NOT NULL,
                    description TEXT NOT NULL,
                    description_kk TEXT NOT NULL,
                    price INTEGER NOT NULL,
                    image_url VARCHAR(255),
                    in_stock BOOLEAN DEFAULT TRUE,
                    stock_quantity INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """)
                
                # Create cart table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS cart_items (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT REFERENCES users(id),
                    product_id INTEGER REFERENCES products(id),
                    quantity INTEGER NOT NULL,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """)
                
                # Create orders table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS orders (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT REFERENCES users(id),
                    status VARCHAR(20) NOT NULL DEFAULT 'pending',
                    total INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    payment_method VARCHAR(50),
                    payment_status VARCHAR(20) DEFAULT 'unpaid',
                    shipping_address TEXT
                )
                """)
                
                # Create order items table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS order_items (
                    id SERIAL PRIMARY KEY,
                    order_id INTEGER REFERENCES orders(id),
                    product_id INTEGER REFERENCES products(id),
                    quantity INTEGER NOT NULL,
                    price INTEGER NOT NULL
                )
                """)
                
                # Create product reviews table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS product_reviews (
                    id SERIAL PRIMARY KEY,
                    product_id INTEGER REFERENCES products(id),
                    user_id BIGINT REFERENCES users(id),
                    rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
                    review_text TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """)
                
                # Create wishlist table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS wishlist_items (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT REFERENCES users(id),
                    product_id INTEGER REFERENCES products(id),
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, product_id)
                )
                """)
                
                # Create FAQ table
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS faqs (
                    id SERIAL PRIMARY KEY,
                    question TEXT NOT NULL,
                    question_kk TEXT NOT NULL,
                    answer TEXT NOT NULL,
                    answer_kk TEXT NOT NULL,
                    category VARCHAR(50),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """)
                
                conn.commit()
        finally:
            self.connection_pool.putconn(conn)
    
    # User methods
    def get_user(self, user_id):
        """Get user by ID."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, name, phone, language, is_admin FROM users WHERE id = %s", (user_id,))
                user_data = cursor.fetchone()
                
                if user_data:
                    return User(user_data[0], user_data[1], user_data[2], user_data[3], user_data[4])
                return None
        finally:
            self.connection_pool.putconn(conn)
    
    def create_user(self, user_id, name, phone, language):
        """Create a new user."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO users (id, name, phone, language) VALUES (%s, %s, %s, %s)",
                    (user_id, name, phone, language)
                )
                conn.commit()
                return User(user_id, name, phone, language, False)
        finally:
            self.connection_pool.putconn(conn)
    
    def update_user_language(self, user_id, language):
        """Update user's language preference."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "UPDATE users SET language = %s WHERE id = %s",
                    (language, user_id)
                )
                conn.commit()
        finally:
            self.connection_pool.putconn(conn)
    
    def set_user_admin(self, user_id, is_admin=True):
        """Set or unset user as admin."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "UPDATE users SET is_admin = %s WHERE id = %s",
                    (is_admin, user_id)
                )
                conn.commit()
        finally:
            self.connection_pool.putconn(conn)
    
    def is_admin(self, user_id):
        """Check if user is an admin."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT is_admin FROM users WHERE id = %s", (user_id,))
                result = cursor.fetchone()
                return result and result[0]
        finally:
            self.connection_pool.putconn(conn)
    
    # Category methods
    def get_categories(self, parent_id=None):
        """Get all product categories."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                if parent_id is None:
                    cursor.execute("SELECT id, name, name_kk, parent_id, image_url FROM categories WHERE parent_id IS NULL")
                else:
                    cursor.execute("SELECT id, name, name_kk, parent_id, image_url FROM categories WHERE parent_id = %s", (parent_id,))
                categories = []
                for row in cursor.fetchall():
                    categories.append(Category(row[0], row[1], row[2], row[3], row[4]))
                return categories
        finally:
            self.connection_pool.putconn(conn)
    
    def get_category(self, category_id):
        """Get category by ID."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, name, name_kk, parent_id, image_url FROM categories WHERE id = %s", (category_id,))
                row = cursor.fetchone()
                if row:
                    return Category(row[0], row[1], row[2], row[3], row[4])
                return None
        finally:
            self.connection_pool.putconn(conn)
    
    def create_category(self, name, name_kk, parent_id=None, image_url=None):
        """Create a new category."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO categories (name, name_kk, parent_id, image_url) VALUES (%s, %s, %s, %s) RETURNING id",
                    (name, name_kk, parent_id, image_url)
                )
                category_id = cursor.fetchone()[0]
                conn.commit()
                return Category(category_id, name, name_kk, parent_id, image_url)
        finally:
            self.connection_pool.putconn(conn)
    
    def update_category(self, category_id, name, name_kk, parent_id=None, image_url=None):
        """Update a category."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "UPDATE categories SET name = %s, name_kk = %s, parent_id = %s, image_url = %s WHERE id = %s",
                    (name, name_kk, parent_id, image_url, category_id)
                )
                conn.commit()
                return Category(category_id, name, name_kk, parent_id, image_url)
        finally:
            self.connection_pool.putconn(conn)
    
    def delete_category(self, category_id):
        """Delete a category."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # First check if there are any products in this category
                cursor.execute("SELECT COUNT(*) FROM products WHERE category_id = %s", (category_id,))
                count = cursor.fetchone()[0]
                if count > 0:
                    return False, "Cannot delete category with products"
                
                # Check if there are subcategories
                cursor.execute("SELECT COUNT(*) FROM categories WHERE parent_id = %s", (category_id,))
                count = cursor.fetchone()[0]
                if count > 0:
                    return False, "Cannot delete category with subcategories"
                
                cursor.execute("DELETE FROM categories WHERE id = %s", (category_id,))
                conn.commit()
                return True, "Category deleted successfully"
        finally:
            self.connection_pool.putconn(conn)
    
    # Product methods
    def get_products_by_category(self, category_id):
        """Get products by category ID."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT id, name, name_kk, description, description_kk, price, image_url, in_stock 
                    FROM products WHERE category_id = %s AND in_stock = TRUE""",
                    (category_id,)
                )
                products = []
                for row in cursor.fetchall():
                    products.append(Product(
                        row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7]
                    ))
                return products
        finally:
            self.connection_pool.putconn(conn)
    
    def get_product(self, product_id):
        """Get product by ID."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT id, name, name_kk, description, description_kk, price, image_url, in_stock 
                    FROM products WHERE id = %s""",
                    (product_id,)
                )
                row = cursor.fetchone()
                if row:
                    return Product(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                return None
        finally:
            self.connection_pool.putconn(conn)
    
    def create_product(self, category_id, name, name_kk, description, description_kk, price, image_url=None, in_stock=True, stock_quantity=0):
        """Create a new product."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """INSERT INTO products 
                    (category_id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id""",
                    (category_id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity)
                )
                product_id = cursor.fetchone()[0]
                conn.commit()
                return Product(product_id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity)
        finally:
            self.connection_pool.putconn(conn)
    
    def update_product(self, product_id, category_id, name, name_kk, description, description_kk, price, image_url=None, in_stock=True, stock_quantity=0):
        """Update a product."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """UPDATE products SET 
                    category_id = %s, name = %s, name_kk = %s, description = %s, description_kk = %s, 
                    price = %s, image_url = %s, in_stock = %s, stock_quantity = %s, updated_at = CURRENT_TIMESTAMP 
                    WHERE id = %s""",
                    (category_id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity, product_id)
                )
                conn.commit()
                return Product(product_id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity)
        finally:
            self.connection_pool.putconn(conn)
    
    def delete_product(self, product_id):
        """Delete a product."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # First check if product is in any cart
                cursor.execute("SELECT COUNT(*) FROM cart_items WHERE product_id = %s", (product_id,))
                count = cursor.fetchone()[0]
                if count > 0:
                    return False, "Cannot delete product that is in users' carts"
                
                # Check if product is in any order
                cursor.execute("SELECT COUNT(*) FROM order_items WHERE product_id = %s", (product_id,))
                count = cursor.fetchone()[0]
                if count > 0:
                    return False, "Cannot delete product that is in orders"
                
                # Delete product reviews
                cursor.execute("DELETE FROM product_reviews WHERE product_id = %s", (product_id,))
                
                # Delete from wishlists
                cursor.execute("DELETE FROM wishlist_items WHERE product_id = %s", (product_id,))
                
                # Delete product
                cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
                conn.commit()
                return True, "Product deleted successfully"
        finally:
            self.connection_pool.putconn(conn)
    
    def search_products(self, query, language='ru'):
        """Search products by name or description."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Use different fields based on language
                if language == 'kk':
                    cursor.execute(
                        """SELECT id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity 
                        FROM products 
                        WHERE (name_kk ILIKE %s OR description_kk ILIKE %s) AND in_stock = TRUE""",
                        (f'%{query}%', f'%{query}%')
                    )
                else:
                    cursor.execute(
                        """SELECT id, name, name_kk, description, description_kk, price, image_url, in_stock, stock_quantity 
                        FROM products 
                        WHERE (name ILIKE %s OR description ILIKE %s) AND in_stock = TRUE""",
                        (f'%{query}%', f'%{query}%')
                    )
                
                products = []
                for row in cursor.fetchall():
                    products.append(Product(
                        row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]
                    ))
                return products
        finally:
            self.connection_pool.putconn(conn)
    
    # Cart methods
    def add_to_cart(self, user_id, product_id, quantity):
        """Add product to user's cart."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Check if product already in cart
                cursor.execute(
                    "SELECT id, quantity FROM cart_items WHERE user_id = %s AND product_id = %s",
                    (user_id, product_id)
                )
                cart_item = cursor.fetchone()
                
                if cart_item:
                    # Update quantity if already in cart
                    new_quantity = cart_item[1] + quantity
                    cursor.execute(
                        "UPDATE cart_items SET quantity = %s WHERE id = %s",
                        (new_quantity, cart_item[0])
                    )
                else:
                    # Add new item to cart
                    cursor.execute(
                        "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (%s, %s, %s)",
                        (user_id, product_id, quantity)
                    )
                conn.commit()
        finally:
            self.connection_pool.putconn(conn)
    
    def get_cart_items(self, user_id):
        """Get all items in user's cart."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT ci.id, ci.product_id, ci.quantity, 
                    p.name, p.name_kk, p.description, p.description_kk, p.price, p.image_url, p.in_stock 
                    FROM cart_items ci 
                    JOIN products p ON ci.product_id = p.id 
                    WHERE ci.user_id = %s""",
                    (user_id,)
                )
                cart_items = []
                for row in cursor.fetchall():
                    product = Product(
                        row[1], row[3], row[4], row[5], row[6], row[7], row[8], row[9]
                    )
                    cart_items.append(CartItem(row[0], product, row[2]))
                return cart_items
        finally:
            self.connection_pool.putconn(conn)
    
    def clear_cart(self, user_id):
        """Remove all items from user's cart."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute("DELETE FROM cart_items WHERE user_id = %s", (user_id,))
                conn.commit()
        finally:
            self.connection_pool.putconn(conn)
    
    # Order methods
    def create_order_from_cart(self, user_id):
        """Create a new order from user's cart items."""
        cart_items = self.get_cart_items(user_id)
        if not cart_items:
            return None
        
        # Calculate total price
        total = sum(item.product.price * item.quantity for item in cart_items)
        
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Create order
                cursor.execute(
                    "INSERT INTO orders (user_id, total) VALUES (%s, %s) RETURNING id",
                    (user_id, total)
                )
                order_id = cursor.fetchone()[0]
                
                # Add order items
                for item in cart_items:
                    cursor.execute(
                        """INSERT INTO order_items (order_id, product_id, quantity, price) 
                        VALUES (%s, %s, %s, %s)""",
                        (order_id, item.product.id, item.quantity, item.product.price)
                    )
                
                # Clear cart
                cursor.execute("DELETE FROM cart_items WHERE user_id = %s", (user_id,))
                
                conn.commit()
                return order_id
        except Exception as e:
            conn.rollback()
            print(f"Error creating order: {e}")
            return None
        finally:
            self.connection_pool.putconn(conn)
    
    def get_user_orders(self, user_id):
        """Get all orders for a user."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "SELECT id, status, total, created_at FROM orders WHERE user_id = %s ORDER BY created_at DESC",
                    (user_id,)
                )
                orders = []
                for row in cursor.fetchall():
                    orders.append(Order(row[0], user_id, row[1], row[2], row[3]))
                return orders
        finally:
            self.connection_pool.putconn(conn)
    
    def update_order_status(self, order_id, status):
        """Update order status."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """UPDATE orders SET status = %s, updated_at = CURRENT_TIMESTAMP 
                    WHERE id = %s""",
                    (status, order_id)
                )
                conn.commit()
                return True
        finally:
            self.connection_pool.putconn(conn)
    
    def get_all_orders(self, status=None, limit=50, offset=0):
        """Get all orders for admin, optionally filtered by status."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                if status:
                    cursor.execute(
                        """SELECT o.id, o.user_id, u.name, u.phone, o.status, o.total, o.created_at, o.payment_method, o.payment_status 
                        FROM orders o 
                        JOIN users u ON o.user_id = u.id 
                        WHERE o.status = %s 
                        ORDER BY o.created_at DESC 
                        LIMIT %s OFFSET %s""",
                        (status, limit, offset)
                    )
                else:
                    cursor.execute(
                        """SELECT o.id, o.user_id, u.name, u.phone, o.status, o.total, o.created_at, o.payment_method, o.payment_status 
                        FROM orders o 
                        JOIN users u ON o.user_id = u.id 
                        ORDER BY o.created_at DESC 
                        LIMIT %s OFFSET %s""",
                        (limit, offset)
                    )
                
                orders = []
                for row in cursor.fetchall():
                    orders.append({
                        'id': row[0],
                        'user_id': row[1],
                        'user_name': row[2],
                        'user_phone': row[3],
                        'status': row[4],
                        'total': row[5],
                        'created_at': row[6],
                        'payment_method': row[7],
                        'payment_status': row[8]
                    })
                return orders
        finally:
            self.connection_pool.putconn(conn)
    
    # Wishlist methods
    def add_to_wishlist(self, user_id, product_id):
        """Add product to user's wishlist."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                try:
                    cursor.execute(
                        "INSERT INTO wishlist_items (user_id, product_id) VALUES (%s, %s)",
                        (user_id, product_id)
                    )
                    conn.commit()
                    return True
                except psycopg2.IntegrityError:
                    # Product already in wishlist (due to UNIQUE constraint)
                    conn.rollback()
                    return False
        finally:
            self.connection_pool.putconn(conn)
    
    def remove_from_wishlist(self, user_id, product_id):
        """Remove product from user's wishlist."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM wishlist_items WHERE user_id = %s AND product_id = %s",
                    (user_id, product_id)
                )
                conn.commit()
                return cursor.rowcount > 0
        finally:
            self.connection_pool.putconn(conn)
    
    def get_wishlist_items(self, user_id):
        """Get all items in user's wishlist."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT w.id, w.product_id, 
                    p.name, p.name_kk, p.description, p.description_kk, p.price, p.image_url, p.in_stock 
                    FROM wishlist_items w 
                    JOIN products p ON w.product_id = p.id 
                    WHERE w.user_id = %s""",
                    (user_id,)
                )
                wishlist_items = []
                for row in cursor.fetchall():
                    product = Product(
                        row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]
                    )
                    wishlist_items.append({"id": row[0], "product": product})
                return wishlist_items
        finally:
            self.connection_pool.putconn(conn)
    
    def is_in_wishlist(self, user_id, product_id):
        """Check if product is in user's wishlist."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "SELECT id FROM wishlist_items WHERE user_id = %s AND product_id = %s",
                    (user_id, product_id)
                )
                return cursor.fetchone() is not None
        finally:
            self.connection_pool.putconn(conn)
    
    # FAQ methods
    def get_faqs(self, language='ru'):
        """Get all FAQs in the specified language."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, question, question_kk, answer, answer_kk, category FROM faqs ORDER BY category, id")
                faqs = []
                for row in cursor.fetchall():
                    faqs.append({
                        'id': row[0],
                        'question': row[1] if language == 'ru' else row[2],
                        'answer': row[3] if language == 'ru' else row[4],
                        'category': row[5]
                    })
                return faqs
        finally:
            self.connection_pool.putconn(conn)
    
    # Product review methods
    def get_product_reviews(self, product_id):
        """Get all reviews for a product."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT r.id, r.user_id, u.name, r.rating, r.review_text, r.created_at 
                    FROM product_reviews r 
                    JOIN users u ON r.user_id = u.id 
                    WHERE r.product_id = %s 
                    ORDER BY r.created_at DESC""",
                    (product_id,)
                )
                reviews = []
                for row in cursor.fetchall():
                    reviews.append({
                        'id': row[0],
                        'user_id': row[1],
                        'user_name': row[2],
                        'rating': row[3],
                        'review_text': row[4],
                        'created_at': row[5]
                    })
                return reviews
        finally:
            self.connection_pool.putconn(conn)
    
    def add_product_review(self, user_id, product_id, rating, review_text):
        """Add a review for a product."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Check if user already reviewed this product
                cursor.execute(
                    "SELECT id FROM product_reviews WHERE user_id = %s AND product_id = %s",
                    (user_id, product_id)
                )
                existing_review = cursor.fetchone()
                
                if existing_review:
                    # Update existing review
                    cursor.execute(
                        """UPDATE product_reviews 
                        SET rating = %s, review_text = %s, created_at = CURRENT_TIMESTAMP 
                        WHERE id = %s""",
                        (rating, review_text, existing_review[0])
                    )
                else:
                    # Add new review
                    cursor.execute(
                        """INSERT INTO product_reviews (user_id, product_id, rating, review_text) 
                        VALUES (%s, %s, %s, %s) RETURNING id""",
                        (user_id, product_id, rating, review_text)
                    )
                
                conn.commit()
                return True
        finally:
            self.connection_pool.putconn(conn)
    
    def get_order_details(self, order_id):
        """Get detailed information about an order."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Get order information
                cursor.execute(
                    """SELECT o.id, o.user_id, u.name, u.phone, o.status, o.total, o.created_at, 
                    o.payment_method, o.payment_status, o.shipping_address 
                    FROM orders o 
                    JOIN users u ON o.user_id = u.id 
                    WHERE o.id = %s""",
                    (order_id,)
                )
                order_row = cursor.fetchone()
                if not order_row:
                    return None
                
                order_info = {
                    'id': order_row[0],
                    'user_id': order_row[1],
                    'user_name': order_row[2],
                    'user_phone': order_row[3],
                    'status': order_row[4],
                    'total': order_row[5],
                    'created_at': order_row[6],
                    'payment_method': order_row[7],
                    'payment_status': order_row[8],
                    'shipping_address': order_row[9],
                    'items': []
                }
                
                # Get order items
                cursor.execute(
                    """SELECT oi.id, oi.product_id, p.name, p.name_kk, oi.quantity, oi.price 
                    FROM order_items oi 
                    JOIN products p ON oi.product_id = p.id 
                    WHERE oi.order_id = %s""",
                    (order_id,)
                )
                
                for item_row in cursor.fetchall():
                    order_info['items'].append({
                        'id': item_row[0],
                        'product_id': item_row[1],
                        'product_name': item_row[2],
                        'product_name_kk': item_row[3],
                        'quantity': item_row[4],
                        'price': item_row[5],
                        'subtotal': item_row[4] * item_row[5]
                    })
                
                return order_info
        finally:
            self.connection_pool.putconn(conn)
    
    def get_user_orders(self, user_id):
        """Get all orders for a user."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "SELECT id, status, total, created_at FROM orders WHERE user_id = %s ORDER BY created_at DESC",
                    (user_id,)
                )
                orders = []
                for row in cursor.fetchall():
                    orders.append(Order(row[0], user_id, row[1], row[2], row[3]))
                return orders
        finally:
            self.connection_pool.putconn(conn)
    
    def cancel_order(self, order_id, user_id=None):
        """Cancel an order. If user_id is provided, verify the order belongs to the user."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                if user_id:
                    # Verify order belongs to user
                    cursor.execute("SELECT id FROM orders WHERE id = %s AND user_id = %s", (order_id, user_id))
                    if not cursor.fetchone():
                        return False, "Order not found or does not belong to user"
                
                # Check if order can be cancelled (only pending or processing orders)
                cursor.execute("SELECT status FROM orders WHERE id = %s", (order_id,))
                status = cursor.fetchone()
                if not status:
                    return False, "Order not found"
                
                if status[0] not in ['pending', 'processing']:
                    return False, f"Cannot cancel order with status '{status[0]}'"
                
                # Cancel order
                cursor.execute(
                    "UPDATE orders SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = %s",
                    (order_id,)
                )
                conn.commit()
                return True, "Order cancelled successfully"
        finally:
            self.connection_pool.putconn(conn)
    
    # Analytics methods
    def get_sales_stats(self, days=30):
        """Get sales statistics for the last X days."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT 
                        COUNT(*) as order_count, 
                        SUM(total) as total_sales,
                        AVG(total) as average_order_value
                    FROM orders 
                    WHERE created_at >= CURRENT_DATE - INTERVAL '%s days'
                    AND status != 'cancelled'""",
                    (days,)
                )
                row = cursor.fetchone()
                return {
                    'order_count': row[0],
                    'total_sales': row[1] or 0,
                    'average_order_value': row[2] or 0
                }
        finally:
            self.connection_pool.putconn(conn)
    
    def get_top_products(self, limit=10):
        """Get top selling products."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT p.id, p.name, p.name_kk, SUM(oi.quantity) as total_sold
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    JOIN orders o ON oi.order_id = o.id
                    WHERE o.status != 'cancelled'
                    GROUP BY p.id, p.name, p.name_kk
                    ORDER BY total_sold DESC
                    LIMIT %s""",
                    (limit,)
                )
                products = []
                for row in cursor.fetchall():
                    products.append({
                        'id': row[0],
                        'name': row[1],
                        'name_kk': row[2],
                        'total_sold': row[3]
                    })
                return products
        finally:
            self.connection_pool.putconn(conn)
    
    def get_category_sales(self):
        """Get sales by category."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """SELECT c.id, c.name, c.name_kk, SUM(oi.quantity * oi.price) as total_sales
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    JOIN categories c ON p.category_id = c.id
                    JOIN orders o ON oi.order_id = o.id
                    WHERE o.status != 'cancelled'
                    GROUP BY c.id, c.name, c.name_kk
                    ORDER BY total_sales DESC"""
                )
                categories = []
                for row in cursor.fetchall():
                    categories.append({
                        'id': row[0],
                        'name': row[1],
                        'name_kk': row[2],
                        'total_sales': row[3]
                    })
                return categories
        finally:
            self.connection_pool.putconn(conn)
    
    # Recommendation methods
    def get_recommended_products(self, user_id, limit=5):
        """Get recommended products for a user based on their order history."""
        conn = self.connection_pool.getconn()
        try:
            with conn.cursor() as cursor:
                # Get categories of products the user has purchased
                cursor.execute(
                    """SELECT DISTINCT p.category_id
                    FROM order_items oi
                    JOIN orders o ON oi.order_id = o.id
                    JOIN products p ON oi.product_id = p.id
                    WHERE o.user_id = %s""",
                    (user_id,)
                )
                category_ids = [row[0] for row in cursor.fetchall()]
                
                if not category_ids:
                    # If user has no order history, return popular products
                    cursor.execute(
                        """SELECT p.id, p.name, p.name_kk, p.description, p.description_kk, 
                        p.price, p.image_url, p.in_stock, p.stock_quantity
                        FROM products p
                        JOIN order_items oi ON p.id = oi.product_id
                        GROUP BY p.id
                        ORDER BY COUNT(oi.id) DESC
                        LIMIT %s""",
                        (limit,)
                    )
                else:
                    # Get products from categories the user has purchased from,
                    # excluding products they've already purchased
                    cursor.execute(
                        """SELECT p.id, p.name, p.name_kk, p.description, p.description_kk, 
                        p.price, p.image_url, p.in_stock, p.stock_quantity
                        FROM products p
                        WHERE p.category_id IN %s
                        AND p.in_stock = TRUE
                        AND p.id NOT IN (
                            SELECT DISTINCT oi.product_id
                            FROM order_items oi
                            JOIN orders o ON oi.order_id = o.id
                            WHERE o.user_id = %s
                        )
                        LIMIT %s""",
                        (tuple(category_ids), user_id, limit)
                    )
                
                products = []
                for row in cursor.fetchall():
                    products.append(Product(
                        row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]
                    ))
                return products
        finally:
            self.connection_pool.putconn(conn)