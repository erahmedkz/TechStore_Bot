# Dictionary of localized text strings for the Telegram bot

# Russian language strings
RU_STRINGS = {
    # Main menu
    'main_menu': 'Главное меню',
    'catalog': 'Каталог товаров',
    'cart': 'Корзина',
    'orders': 'Мои заказы',
    'settings': 'Настройки',
    'back': 'Назад',
    'search': 'Поиск товаров',
    'wishlist': 'Избранное',
    'faq': 'Часто задаваемые вопросы',
    
    # Registration
    'ask_name': 'Пожалуйста, введите ваше имя:',
    'ask_phone': 'Пожалуйста, введите ваш номер телефона:',
    'registration_complete': 'Регистрация завершена! Добро пожаловать в наш магазин.',
    
    # Catalog
    'choose_category': 'Выберите категорию:',
    'choose_product': 'Выберите товар:',
    'add_to_cart': 'Добавить в корзину',
    'add_to_wishlist': 'Добавить в избранное',
    'remove_from_wishlist': 'Удалить из избранного',
    'price': 'Цена',
    'in_stock': 'В наличии',
    'out_of_stock': 'Нет в наличии',
    'stock_quantity': 'Количество на складе',
    'product_rating': 'Рейтинг',
    'product_reviews': 'Отзывы',
    'write_review': 'Написать отзыв',
    'share_product': 'Поделиться товаром',
    'similar_products': 'Похожие товары',
    'search_results': 'Результаты поиска',
    'no_search_results': 'По вашему запросу ничего не найдено',
    'search_placeholder': 'Введите название товара',
    
    # Cart
    'added_to_cart': 'Товар добавлен в корзину!',
    'continue_shopping': 'Продолжить покупки',
    'go_to_cart': 'Перейти в корзину',
    'your_cart': 'Ваша корзина:',
    'empty_cart': 'Ваша корзина пуста.',
    'total': 'Итого',
    'checkout': 'Оформить заказ',
    'clear_cart': 'Очистить корзину',
    'cart_cleared': 'Корзина очищена.',
    'update_quantity': 'Изменить количество',
    'remove_from_cart': 'Удалить из корзины',
    
    # Orders
    'order_created': 'Заказ #{order_id} успешно создан! Наш менеджер свяжется с вами в ближайшее время.',
    'checkout_error': 'Произошла ошибка при оформлении заказа. Пожалуйста, попробуйте еще раз.',
    'your_orders': 'Ваши заказы:',
    'no_orders': 'У вас пока нет заказов.',
    'order_status_pending': 'Ожидает обработки',
    'order_status_processing': 'В обработке',
    'order_status_shipped': 'Отправлен',
    'order_status_delivered': 'Доставлен',
    'order_status_cancelled': 'Отменен',
    'order_details': 'Детали заказа',
    'order_date': 'Дата заказа',
    'order_status': 'Статус заказа',
    'order_total': 'Сумма заказа',
    'order_items': 'Товары в заказе',
    'cancel_order': 'Отменить заказ',
    'track_order': 'Отследить заказ',
    'payment_method': 'Способ оплаты',
    'payment_status': 'Статус оплаты',
    'shipping_address': 'Адрес доставки',
    
    # Wishlist
    'your_wishlist': 'Ваш список желаний',
    'empty_wishlist': 'Ваш список желаний пуст',
    'added_to_wishlist': 'Товар добавлен в избранное',
    'removed_from_wishlist': 'Товар удален из избранного',
    
    # Settings
    'change_language': 'Изменить язык',
    'change_phone': 'Изменить номер телефона',
    'notification_settings': 'Настройки уведомлений',
    
    # Admin panel
    'admin_panel': 'Панель администратора',
    'manage_products': 'Управление товарами',
    'manage_categories': 'Управление категориями',
    'manage_orders': 'Управление заказами',
    'manage_users': 'Управление пользователями',
    'add_product': 'Добавить товар',
    'edit_product': 'Редактировать товар',
    'delete_product': 'Удалить товар',
    'add_category': 'Добавить категорию',
    'edit_category': 'Редактировать категорию',
    'delete_category': 'Удалить категорию',
    'product_name': 'Название товара',
    'product_name_kk': 'Название товара (каз)',
    'product_description': 'Описание товара',
    'product_description_kk': 'Описание товара (каз)',
    'product_price': 'Цена товара',
    'product_image': 'Изображение товара',
    'product_category': 'Категория товара',
    'product_stock': 'Наличие на складе',
    'product_quantity': 'Количество',
    'category_name': 'Название категории',
    'category_name_kk': 'Название категории (каз)',
    'parent_category': 'Родительская категория',
    'category_image': 'Изображение категории',
    'product_saved': 'Товар сохранен',
    'product_deleted': 'Товар удален',
    'category_saved': 'Категория сохранена',
    'category_deleted': 'Категория удалена',
    'order_updated': 'Заказ обновлен',
    'search_products': 'Поиск товаров',
    'search_categories': 'Поиск категорий',
    'search_orders': 'Поиск заказов',
    'export_products': 'Экспорт товаров',
    'import_products': 'Импорт товаров',
    'analytics': 'Аналитика',
    'sales_report': 'Отчет по продажам',
    'inventory_report': 'Отчет по складу',
    
    # FAQ
    'faq_title': 'Часто задаваемые вопросы',
    'contact_support': 'Связаться с поддержкой'
}

# Kazakh language strings
KK_STRINGS = {
    # Main menu
    'main_menu': 'Басты мәзір',
    'catalog': 'Тауарлар каталогы',
    'cart': 'Себет',
    'orders': 'Менің тапсырыстарым',
    'settings': 'Параметрлер',
    'back': 'Артқа',
    'search': 'Тауарларды іздеу',
    'wishlist': 'Таңдаулылар',
    'faq': 'Жиі қойылатын сұрақтар',
    
    # Registration
    'ask_name': 'Өтінемін, атыңызды енгізіңіз:',
    'ask_phone': 'Өтінемін, телефон нөміріңізді енгізіңіз:',
    'registration_complete': 'Тіркеу аяқталды! Дүкенімізге қош келдіңіз.',
    
    # Catalog
    'choose_category': 'Санатты таңдаңыз:',
    'choose_product': 'Тауарды таңдаңыз:',
    'add_to_cart': 'Себетке қосу',
    'add_to_wishlist': 'Таңдаулыларға қосу',
    'remove_from_wishlist': 'Таңдаулылардан жою',
    'price': 'Бағасы',
    'in_stock': 'Қолда бар',
    'out_of_stock': 'Қолда жоқ',
    'stock_quantity': 'Қоймадағы саны',
    'product_rating': 'Рейтинг',
    'product_reviews': 'Пікірлер',
    'write_review': 'Пікір жазу',
    'share_product': 'Тауармен бөлісу',
    'similar_products': 'Ұқсас тауарлар',
    'search_results': 'Іздеу нәтижелері',
    'no_search_results': 'Сіздің сұрауыңыз бойынша ештеңе табылмады',
    'search_placeholder': 'Тауар атауын енгізіңіз',
    
    # Cart
    'added_to_cart': 'Тауар себетке қосылды!',
    'continue_shopping': 'Сауда жасауды жалғастыру',
    'go_to_cart': 'Себетке өту',
    'your_cart': 'Сіздің себетіңіз:',
    'empty_cart': 'Сіздің себетіңіз бос.',
    'total': 'Барлығы',
    'checkout': 'Тапсырысты рәсімдеу',
    'clear_cart': 'Себетті тазалау',
    'cart_cleared': 'Себет тазаланды.',
    'update_quantity': 'Санын өзгерту',
    'remove_from_cart': 'Себеттен жою',
    
    # Orders
    'order_created': 'Тапсырыс #{order_id} сәтті жасалды! Біздің менеджер жақын арада сізбен байланысады.',
    'checkout_error': 'Тапсырысты рәсімдеу кезінде қате орын алды. Өтінемін, қайталап көріңіз.',
    'your_orders': 'Сіздің тапсырыстарыңыз:',
    'no_orders': 'Сізде әлі тапсырыстар жоқ.',
    'order_status_pending': 'Өңдеуді күтуде',
    'order_status_processing': 'Өңделуде',
    'order_status_shipped': 'Жіберілді',
    'order_status_delivered': 'Жеткізілді',
    'order_status_cancelled': 'Бас тартылды',
    'order_details': 'Тапсырыс мәліметтері',
    'order_date': 'Тапсырыс күні',
    'order_status': 'Тапсырыс күйі',
    'order_total': 'Тапсырыс сомасы',
    'order_items': 'Тапсырыстағы тауарлар',
    'cancel_order': 'Тапсырысты болдырмау',
    'track_order': 'Тапсырысты бақылау',
    'payment_method': 'Төлем әдісі',
    'payment_status': 'Төлем күйі',
    'shipping_address': 'Жеткізу мекенжайы',
    
    # Wishlist
    'your_wishlist': 'Сіздің таңдаулыларыңыз',
    'empty_wishlist': 'Сіздің таңдаулылар тізіміңіз бос',
    'added_to_wishlist': 'Тауар таңдаулыларға қосылды',
    'removed_from_wishlist': 'Тауар таңдаулылардан жойылды',
    
    # Settings
    'change_language': 'Тілді өзгерту',
    'change_phone': 'Телефон нөмірін өзгерту',
    'notification_settings': 'Хабарландыру параметрлері',
    
    # Admin panel
    'admin_panel': 'Әкімші панелі',
    'manage_products': 'Тауарларды басқару',
    'manage_categories': 'Санаттарды басқару',
    'manage_orders': 'Тапсырыстарды басқару',
    'manage_users': 'Пайдаланушыларды басқару',
    'add_product': 'Тауар қосу',
    'edit_product': 'Тауарды өңдеу',
    'delete_product': 'Тауарды жою',
    'add_category': 'Санат қосу',
    'edit_category': 'Санатты өңдеу',
    'delete_category': 'Санатты жою',
    'product_name': 'Тауар атауы',
    'product_name_kk': 'Тауар атауы (қаз)',
    'product_description': 'Тауар сипаттамасы',
    'product_description_kk': 'Тауар сипаттамасы (қаз)',
    'product_price': 'Тауар бағасы',
    'product_image': 'Тауар суреті',
    'product_category': 'Тауар санаты',
    'product_stock': 'Қоймада бар',
    'product_quantity': 'Саны',
    'category_name': 'Санат атауы',
    'category_name_kk': 'Санат атауы (қаз)',
    'parent_category': 'Ата-аналық санат',
    'category_image': 'Санат суреті',
    'product_saved': 'Тауар сақталды',
    'product_deleted': 'Тауар жойылды',
    'category_saved': 'Санат сақталды',
    'category_deleted': 'Санат жойылды',
    'order_updated': 'Тапсырыс жаңартылды',
    'search_products': 'Тауарларды іздеу',
    'search_categories': 'Санаттарды іздеу',
    'search_orders': 'Тапсырыстарды іздеу',
    'export_products': 'Тауарларды экспорттау',
    'import_products': 'Тауарларды импорттау',
    'analytics': 'Аналитика',
    'sales_report': 'Сату туралы есеп',
    'inventory_report': 'Қойма туралы есеп',
    
    # FAQ
    'faq_title': 'Жиі қойылатын сұрақтар',
    'contact_support': 'Қолдау қызметіне хабарласу'
}

def get_text(key, language):
    """Get localized text string.
    
    Args:
        key (str): The text key to look up
        language (str): Language code ('ru' or 'kk')
        
    Returns:
        str: Localized text string
    """
    if language == 'kk':
        return KK_STRINGS.get(key, key)
    else:  # Default to Russian
        return RU_STRINGS.get(key, key)