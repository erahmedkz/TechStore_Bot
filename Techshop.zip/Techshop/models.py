class User:
    """User model for the Telegram bot."""
    
    def __init__(self, id, name, phone, language, is_admin=False):
        self.id = id
        self.name = name
        self.phone = phone
        self.language = language
        self.is_admin = is_admin


class Category:
    """Product category model."""
    
    def __init__(self, id, name, name_kk):
        self.id = id
        self.name = name
        self.name_kk = name_kk
        
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = value


class Product:
    """Product model."""
    
    def __init__(self, id, name, name_kk, description, description_kk, price, image_url=None, in_stock=True):
        self.id = id
        self.name = name
        self.name_kk = name_kk
        self.description = description
        self.description_kk = description_kk
        self.price = price
        self.image_url = image_url
        self.in_stock = in_stock
        
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = value
        
    @property
    def description(self):
        return self._description
    
    @description.setter
    def description(self, value):
        self._description = value


class CartItem:
    """Cart item model."""
    
    def __init__(self, id, product, quantity):
        self.id = id
        self.product = product
        self.quantity = quantity


class Cart:
    """Shopping cart model."""
    
    def __init__(self, user_id):
        self.user_id = user_id
        self.items = []
        
    def add_item(self, item):
        self.items.append(item)
        
    def remove_item(self, item_id):
        self.items = [item for item in self.items if item.id != item_id]
        
    def clear(self):
        self.items = []
        
    @property
    def total(self):
        return sum(item.product.price * item.quantity for item in self.items)


class OrderItem:
    """Order item model."""
    
    def __init__(self, id, product, quantity, price):
        self.id = id
        self.product = product
        self.quantity = quantity
        self.price = price


class Order:
    """Order model."""
    
    def __init__(self, id, user_id, status, total, created_at, items=None):
        self.id = id
        self.user_id = user_id
        self.status = status
        self.total = total
        self.created_at = created_at
        self.items = items or []
        
    def add_item(self, item):
        self.items.append(item)